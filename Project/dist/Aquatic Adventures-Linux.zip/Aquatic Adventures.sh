#!/bin/sh
java  -jar Aquatic Adventures.jar
        